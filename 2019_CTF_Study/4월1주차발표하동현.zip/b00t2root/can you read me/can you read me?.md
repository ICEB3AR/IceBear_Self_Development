﻿


![](https://i.imgur.com/1LkN9KE.png)

```
Alice is trying to say something... Can you figure it out.

  

pikachu pika pikachu pika pika pi pi pika pikachu pika pikachu pi pikachu pi pikachu pi pika pi pikachu pikachu pi pi pika pika pikachu pika pikachu pikachu pi pika pi pika pika pi pikachu pikachu pi pikachu pi pika pikachu pi pikachu pika pikachu pi pikachu pikachu pi pikachu pika pika pikachu pi pikachu pi pi pikachu pikachu pika pikachu pi pika pi pi pika pika pikachu pikachu pi pi pikachu pi pikachu

pikachu pikachu pi pikachu

pikachu pika pika pikachu pika pikachu pikachu pika pika pikachu pikachu pi pi pikachu pika pikachu pika pika pi pika pikachu pikachu pi pika pika pikachu pi pika pi pika pi pikachu pi pikachu pika pika pi pi pika pi pika pika pikachu pikachu pika pikachu pikachu pika pi pikachu pika pi pikachu pi pika pika pi pikachu pika pi pika pikachu pi pi pikachu pika pika pi pika pi pikachu

pikachu pikachu pi pikachu

pikachu pika pi pika pika pikachu pika pikachu pi pikachu pi pi pika pi pikachu pika pi pi pika pikachu pi pikachu pi pi pikachu pikachu pika pikachu pikachu pika pi pikachu pi pika pikachu pi pikachu pika pika pikachu pika pi pi pikachu pikachu pika pika pikachu pi pika pikachu pikachu pi pika pikachu pikachu pika pi pi pikachu pikachu pi pikachu pi pikachu pi pikachu pi pika pikachu pi pikachu pika pikachu pi pika pi pikachu

pi pika

pikachu pikachu pi pikachu

pika pi

pikachu pikachu pi pikachu

pikachu pi pikachu pi pi pikachu pi pikachu pika pikachu pikachu pi pikachu pikachu pika pi pi pika pikachu pika pikachu pi pi pikachu pika pi pi pikachu pika pika pi pika pika pikachu pika pikachu pi pi pika pikachu pika pi pikachu pikachu pi pikachu pika pikachu pikachu pika pi pi pikachu pikachu pi pika pikachu pi pikachu pika pikachu pikachu pika pi pikachu pikachu pika pikachu pi pikachu pika pika pi pikachu pi pika pi pikachu pikachu pi pikachu

pi pika

pikachu pikachu pi pikachu

pikachu pikachu pi pika pikachu pi pika pika pi pi pika pi pikachu pi pika pi pika pi pika pikachu pika pi pi pikachu pi pikachu pi pika pi pika pika pikachu pi pikachu

pikachu pikachu pi pikachu

pikachu pi pikachu pika pikachu pi pika pi pikachu pikachu pika pika pi pi pikachu pi pika pi pikachu pi pika pikachu pi pika pi pi pikachu pikachu pika pika pikachu pikachu pi pi pikachu pi pikachu pi pikachu pi pi pikachu pikachu pi pikachu pi pikachu pi pika pika pikachu pikachu pika pi pika pikachu pi pikachu pi pi pika pikachu pika pi pikachu pi pika pi pi pikachu pikachu pika pika pikachu pika pika pikachu pi pika pi pika pikachu pi pika pikachu pika pi pika pikachu

pikachu pikachu pika pikachu

pikachu pikachu pika pikachu

pi pi pikachu pi pikachu pika pika pi pikachu pika pika pi pi pika pika pikachu pi pi pikachu pi pika pi pika pikachu pi pikachu pi pikachu pikachu pi pi pika pika pi pika pika pi pika pikachu pikachu pi pikachu pika pi pi pika pi pi pikachu pikachu pika pi pi pika pika pi pika pikachu pi pikachu pi pi pika pi pika pika pikachu pika pi pika pikachu pi pikachu pikachu pi pi pika pi pika pika pikachu pikachu pi pikachu

pikachu pikachu pi pikachu

pikachu pi pikachu pikachu pika pikachu pikachu pika pika pikachu pikachu pika pikachu pi pika pikachu pika pika pi pikachu pi pi pika pi pi pikachu pika pika pikachu pikachu pika pikachu pikachu pi pika pi pi pikachu pikachu pika pi pi pikachu pikachu pika pikachu pika pi pikachu pi pika pi pika pikachu pika pi pikachu pi pikachu pikachu pi pika pikachu pi pikachu pikachu pi pika pi pikachu pikachu pi pikachu pika pika pi pi pikachu

pikachu pi pi pika pi pi pikachu pika pikachu pikachu pika pika pi pi pika pikachu pi pikachu pi pi pika pi pika pi pi pika pikachu pi pika pi pikachu pika pikachu pika pi pi pika pi pi pikachu pi pikachu pikachu pika pi pikachu pi pi pika pi pikachu pi pi pika pi pi pikachu pika pikachu pika pikachu pika pi pikachu pikachu pi pi pika pika pikachu

pikachu pikachu pi pikachu

pikachu pikachu pika pikachu

  

Did you get it??:
```

[pikachu language](http://trove42.com/introducing-pikachu-programming-language/)

![](https://i.imgur.com/I4krtmq.png)

위 사이트에 웹상에서 실행한 링크가 있어 돌려보면 HELLO WORLD가 출력되고 입력으로 주면 다음문제가 나타납니다.

```
Alice is trying to say something... Can you figure it out.
++++++++++[>+>+++>+++++++>++++++++++<<<<-]>>>++++++++++++++.>++++.+.++++++++++.<<++.>>----------.++++++++++.<<.>>-------------.<<++++++++++..>>+++++.--.+++++.-------.<<----------.>>++++++.++++++++++++.<<.>++++++++++++++.>-------.<-.++++++++.>----.
Did you get it??:
```

brain fuck으로 실행해보면
```
This is f**king my brain
```
이를 입력으로 입력하면 다음문제가 나타납니다.

```
Alice is trying to say something... Can you figure it out.

D'`_$L]~};:WW7wTuQPsr`p-,JI)iEEfBBA!~P<^)Lrqp6tsrqSi/.lkjLKa'eG]baZ~A@\[ZYXQuUN6RKJONGkj-CBG@?>b<;:9]=<5:3W70v.3,P*p.-&J*j(!~}C#cy~}v<z\xwp6tVrkjoh.lejihg`&GFbaZ~^]?>ZSwWP8Nr5KPONMFEiIHA)E>b<$:9>7[54321U/u321*N.nm%*#"F&fe#z@~wv<tyxwvo5slqpihmle+ihgIed]#aCY^W\[TxRWVUTSLKoONML.DhHG)(>=<`#?8\<;43W7w/43,P0po'&%$)(!E2

Did you get it??:
```

이번 언어는 어떤 언어인지 감이 안잡혀서

[esolang](https://esolangs.org/wiki/Language_list)
위와 같은 사이트를 참고해서 

Malboge언어라는 것을 눈치로 알아내었습니다..!


![](https://i.imgur.com/0e6wDbF.png)
이 또한 웹상에서 실행해서 flag를 알아내었습니다.
